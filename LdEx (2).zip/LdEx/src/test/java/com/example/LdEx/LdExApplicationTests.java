package com.example.LdEx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LdExApplicationTests {

	@Test
	void contextLoads() {
	}

}
