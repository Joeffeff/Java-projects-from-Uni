package Im;
import java.util.Collections;
import java.util.Comparator;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

//Parduotuve atvira nuo 6 val ryto iki 10 val vakaro
abstract class Inventorius{ //abstrakti klase, daiktai esantys parduotuveje
    protected String ID;
    public Inventorius(String ID){this.ID = ID;}
    public String getID(){return this.ID;}
    public abstract double pinigu_pokytis(); //abstraktus metodas, grąžina pokytį parduotuvės finansuose
}
//
class Iranga extends Inventorius{
    enum invent { //įrangos tipas, pažymėta kiek vatų naudoja
        saldytuvas(0.3), //kWh
        saldiklis(0.25),
        kasa(0.45),
        kompiuteris(0.5),
        lempa(0.1),
        other(0);

        private double elektra;
        invent(double elektra) {this.elektra = elektra;}
        public double getWattage() {return elektra;}
    }
    int tipas;
    double Watts;
    LocalDate pirkimoData;
    double elect_cost = 0.197; //Lietuvoje elektros kaina Eur/kWh
    public Iranga (String ID, int type, LocalDate buy_date){
        super(ID);
        this.tipas=type;
        invent[] tipai = invent.values();
        this.Watts = tipai[tipas].getWattage();
        this.pirkimoData = buy_date;
    }
    public double getWatts(){return this.Watts;}
    public LocalDate getPirkimoData(){return this.pirkimoData;}

    public double apmoketa_elektra(){
        return this.Watts*16*ChronoUnit.DAYS.between(this.pirkimoData, LocalDate.now());
    }
    @Override
    public double pinigu_pokytis(){ //atimta iš 0, nes reikia apmokėti už sunaudotą elektrą, padauginta iš 16, nes tiek laiko parduotuvė buvo atvira
        double pokytis = 0-this.Watts*16*this.elect_cost;
        return pokytis;
    }


}

class Preke extends Inventorius{
    private double cost, spent;
    private int amountSold, amountPrad;
    public Preke (String ID, double kaina, double uzsak_kaina, int pard_kiek, int prad_kiek){
        super(ID);
        this.cost = kaina;
        this.spent = uzsak_kaina;
        this.amountSold = pard_kiek;
        this.amountPrad = prad_kiek; //kiek dienos pradžioje buvo prekės parduotuvėje
    }
    public double getCost(){return this.cost;}
    public int getAmountSold(){return this.amountSold;}
    public int getAmountPrad(){return this.amountPrad;}
    public double currentVerte(){ //suskaičiuojama kokia yra piniginė vertė prekės, kuri dar šiuo metu yra parduotuvėje
        return (this.amountPrad- this.amountSold)* this.cost;
    }
    @Override
    public double pinigu_pokytis(){
        double pokytis = this.cost*this.amountSold - this.spent*this.amountSold;
        return pokytis;
    } //pelnas už parduotas prekes

}
//kolekcija kuri susideda is parduotuves inventoriaus (parduodamu, neparduodamu)
class Parduotuve{
    private String name;
    private List<Inventorius> store;
    protected double pokytisSum=0, currentTotalvalue=0, irangosElectSum=0;
    public Parduotuve(String name){
        this.name = name;
        this.store = new ArrayList<>();
        int itemkiek = ThreadLocalRandom.current().nextInt(2, 5); //kiek inventoriaus yra parduotuvėje
        int nonsold=0 , sold=0; //pažymėjimas kiek yra įrangos, kiek prekių, kad pavadinimus patogiau suteikti
        for(int j = 0; j<itemkiek; j++) {
            int k = ThreadLocalRandom.current().nextInt(0, 2); //atsiktinai nusprendžiama ar tai prekė ar įranga

            if (k == 0) {
                nonsold++;
                long minDay = LocalDate.of(2000, 1, 1).toEpochDay();
                long maxDay = LocalDate.now().toEpochDay();
                long randomDay = ThreadLocalRandom.current().nextLong(minDay, maxDay);
                LocalDate randomDate = LocalDate.ofEpochDay(randomDay);
                int type = ThreadLocalRandom.current().nextInt(0, 6);
                this.store.add(new Iranga("Iranga"+nonsold,type,randomDate));
            }
            if (k == 1){
                sold++;
                double uzsak_kaina = ThreadLocalRandom.current().nextDouble(0.2, 100.0);
                double pard_kaina = ThreadLocalRandom.current().nextDouble(0.2, uzsak_kaina);
                int pradinis = ThreadLocalRandom.current().nextInt(3, 51);
                int parduota = ThreadLocalRandom.current().nextInt(0, pradinis);
                this.store.add(new Preke("Preke"+sold,pard_kaina,uzsak_kaina,parduota, pradinis));

            }
    }}
    //public void addInventory(Inventorius item){
    //    this.store.add(item);
    //}
    public String getName(){
        return this.name;
    }

    public List<Inventorius> getList(){return this.store;}
    public double calcPokytisSum(){
        for(Inventorius item : store){this.pokytisSum+=item.pinigu_pokytis();}
        return this.pokytisSum;
    }
    public double calcSenSum(){
        for(Inventorius item : store){
            if(item instanceof Iranga){
                this.irangosElectSum+= (int) ((Iranga) item).apmoketa_elektra();
            }
        }
        return this.irangosElectSum;
    }
    public double calcTotalValue(){
        for(Inventorius item : store){
            if(item instanceof Preke) {
                this.currentTotalvalue += ((Preke) item).currentVerte();
            }
        }
        return this.currentTotalvalue;
    }
}
//kolekcija kuri susideda is parduotuviu
class Imone extends ArrayList<Parduotuve>{
    private String name;
    public Imone(String name){
        this.name = name;
        int pardkiek = ThreadLocalRandom.current().nextInt(2, 6);
        for (int i = 0; i < pardkiek; i++){
            Parduotuve parduotuve = new Parduotuve("Parduotuve"+(i+1));
            this.add(parduotuve);
        }
    }
    public void SortByMoney(){
        Collections.sort(this,new SortMoney());
    }
    public void SortByCurrentTotal(){
        Collections.sort(this,new SortCurrentTotal());
    }
    public void SortByIrangosSum(){
        Collections.sort(this,new SortIrangosSum());
    }

}
class SortMoney implements Comparator<Parduotuve>{
    public int compare(Parduotuve a, Parduotuve b){return (int) (a.calcPokytisSum() - b.calcPokytisSum());}
}
class SortCurrentTotal implements Comparator<Parduotuve>{
    public int compare (Parduotuve a, Parduotuve b){return (int) (a.calcTotalValue() - b.calcTotalValue());}
}
class SortIrangosSum implements Comparator<Parduotuve>{
    public int compare (Parduotuve a, Parduotuve b){return (int) (a.calcSenSum() - b.calcSenSum());}
}

public class Main {
    public static void main(String[] args) {
        Imone imone = new Imone("Imone34");

         //parduotuvių kiekis
//        for (int i = 0; i < pardkiek; i++) {
//            Parduotuve parduotuve = new Parduotuve("Parduotuve"+(i+1));
//            int itemkiek = ThreadLocalRandom.current().nextInt(5, 10); //kiek inventoriaus yra parduotuvėje
//            int nonsold=0 , sold=0; //pažymėjimas kiek yra įrangos, kiek prekių, kad pavadinimus patogiau suteikti
//            for(int j = 0; j<itemkiek; j++) {
//                int k = ThreadLocalRandom.current().nextInt(0, 2); //atsiktinai nusprendžiama ar tai prekė ar įranga
//
//                if (k == 0) {
//                    nonsold++;
//                    long minDay = LocalDate.of(2000, 1, 1).toEpochDay();
//                    long maxDay = LocalDate.now().toEpochDay();
//                    long randomDay = ThreadLocalRandom.current().nextLong(minDay, maxDay);
//                    LocalDate randomDate = LocalDate.ofEpochDay(randomDay);
//                    int type = ThreadLocalRandom.current().nextInt(0, 6);
//                    parduotuve.addInventory(new Iranga("Iranga"+nonsold,type,randomDate));
//                }
//                if (k == 1){
//                    sold++;
//                    double kaina = ThreadLocalRandom.current().nextDouble(0.2, 100.0);
//                    int pradinis = ThreadLocalRandom.current().nextInt(3, 51);
//                    int parduota = ThreadLocalRandom.current().nextInt(0, pradinis);
//                    parduotuve.addInventory(new Preke("Preke"+sold,kaina,parduota, pradinis));
//
//                }
//            }
//            imone.add(parduotuve);
//
//        }

        //uzd 3
        for(Parduotuve store : imone){

            System.out.println("Kolekcija:");
            System.out.println("Parduotuvės pavadinimas: "+store.getName());
            System.out.printf("Įrangos sunaudotos elektros suma Eur (individualus): %.2f Eur \n" ,store.calcSenSum());
            System.out.printf("Turimų prekių vertės suma (individualus): %.2f Eur \n", store.calcTotalValue());
            System.out.printf("Parduotuvės pinigų suma (užklojamas): %.2f Eur \n", store.calcPokytisSum());
            System.out.println("Kolekcijos objektai:");
            for(Inventorius item : store.getList()){
                System.out.println("Objekto ID: "+item.getID());
                if(item instanceof Iranga){
                    System.out.println("Įranga nupirkta: "+((Iranga) item).getPirkimoData());
                    System.out.printf("Įrangos galia: %.1f kW \n",((Iranga) item).getWatts());
                    System.out.printf("Įrangos sunaudota elektra (Eur) (individualus): %.2f Eur \n" ,((Iranga) item).apmoketa_elektra());
                }
                if(item instanceof Preke){
                    System.out.printf("Prekės kaina: %.2f Eur \n",((Preke) item).getCost());
                    System.out.println("Prekės parduotas kiekis: "+((Preke) item).getAmountSold());
                    System.out.println("Prekės kiekis pradžioje dienos: "+((Preke) item).getAmountPrad());
                    System.out.printf("Prekės turimo kiekio vertė (individualus): %.2f Eur \n",((Preke) item).currentVerte());
                }
                System.out.printf("Pinigų pokytis dėl inventoriaus: %.2f Eur \n",item.pinigu_pokytis());
                System.out.println(" ");
            }

        }
        //uzd 4
        System.out.println("Rūšiuota pagal parduotuvės pinigų sumą (bendras):");
        imone.SortByMoney();
        for(Parduotuve store : imone){

            System.out.println("Parduotuvės pavadinimas: " + store.getName());
            System.out.printf("Parduotuvės pinigų suma: %.2f Eur \n", store.calcPokytisSum());
        }
        System.out.println(" ");
        //uzd 5
        System.out.println("Rūšiuota pagal įrangos sunaudotą elektrą (individualus):");
        imone.SortByIrangosSum();
        for(Parduotuve store : imone){
            System.out.println("Parduotuvės pavadinimas: " + store.getName());
            System.out.printf("Įrangos sunaudotos elektros suma Eur (individualus): %.2f Eur \n" ,store.calcSenSum());
        }
        System.out.println(" ");
        System.out.println("Rūšiuota pagal turimų prekių vertės sumą (individualus):");
        imone.SortByCurrentTotal();
        for(Parduotuve store : imone){
            System.out.println("Parduotuvės pavadinimas: " + store.getName());
            System.out.printf("Turimų prekių vertės suma: %.2f Eur \n", store.calcTotalValue());
        }
    }
}