import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

public class PrekeGUI extends JFrame {
    private PrekeDAO prekeDAO;
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField searchField;

    public PrekeGUI() {
        prekeDAO = new PrekeDAO();

        setTitle("Prekių sąrašas");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Viršutinis panelis su paieška
        JPanel panel = new JPanel(new BorderLayout());
        searchField = new JTextField(20);
        JButton searchButton = new JButton("Ieškoti");
        panel.add(new JLabel("Ieškoti pagal ID fragmentą: "), BorderLayout.WEST);
        panel.add(searchField, BorderLayout.CENTER);
        panel.add(searchButton, BorderLayout.EAST);
        add(panel, BorderLayout.SOUTH);

        // Lentelė
        tableModel = new DefaultTableModel();
        tableModel.addColumn("ID");
        tableModel.addColumn("Prekės pavadinimas");
        tableModel.addColumn("Kaina");
        tableModel.addColumn("Turimas Kiekis");
        tableModel.addColumn("Parduotas Kiekis");
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Paieškos mygtuko veiksmas
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String idFragment = searchField.getText();
                loadTableData(idFragment);
            }
        });

        // Mygtukas naujai prekei pridėti
        JButton addButton = new JButton("Pridėti naują prekę");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AddPrekeDialog(PrekeGUI.this).setVisible(true);
            }
        });
        add(addButton, BorderLayout.NORTH);

        loadTableData(""); // Įkeliame visus duomenis iš DB
    }

    private void loadTableData(String idFragment) {
        List<Preke> prekes = prekeDAO.selectPrekesByIdFragment(idFragment);
        tableModel.setRowCount(0); // Išvalome lentelę
        for (Preke preke : prekes) {
            tableModel.addRow(new Object[]{preke.getId(), preke.getName(), preke.getKaina(), preke.getTurimasKiekis(), preke.getParduotasKiekis()});
        }
    }
}
class AddPrekeDialog extends JDialog{
    private JTextField idField, nameField, kainaField, soldField, heldField;
    private PrekeDAO prekeDAO;
    public AddPrekeDialog(JFrame parent) {
//        JDialog dialog = new JDialog(this, "Pridėti naują prekę", true);
//        dialog.setLayout(new GridLayout(5, 2));
//
//        JLabel kainaLabel = new JLabel("Kaina:");
        super(parent, "Pridėti prekę", true);
        prekeDAO = new PrekeDAO();
        setSize(400, 300);
        setLayout(new GridLayout(6, 2));


        add(new JLabel("Pavadinimas:"));
        nameField = new JTextField();
        add(nameField);

        add(new JLabel("Kaina:"));
        kainaField = new JTextField();
        add(kainaField);

        add(new JLabel("Turimas kiekis:"));
        heldField = new JTextField();
        add(heldField);

        add(new JLabel("Parduotas kiekis:"));
        soldField = new JTextField();
        add(soldField);

        JButton addButton = new JButton("Add");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addPreke();
            }
        });

        add(new JLabel(""));
        add(addButton);
    }
    private void addPreke() {
        String id = "0";
        String name = nameField.getText();
        double kaina = Double.parseDouble(kainaField.getText());
        int sold = Integer.parseInt(soldField.getText());
        int held = Integer.parseInt((heldField.getText()));

        Preke preke = new Preke(id, name, kaina, sold, held);
        try {
            prekeDAO.insertPreke(preke);
            JOptionPane.showMessageDialog(this, "Preke added successfully!");
            dispose();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error adding preke.");
        }
    }

}