public class Preke {
    private String id;
    private String name;
    private double kaina;
    private int turimasKiekis;
    private int parduotasKiekis;


    public Preke(String id, String name, double kaina, int turimasKiekis, int parduotasKiekis) {
        this.id = id;
        this.name = name;
        this.kaina = kaina;
        this.turimasKiekis = turimasKiekis;
        this.parduotasKiekis = parduotasKiekis;
    }

    // Getteriai ir Setteriai
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    public String getName(){
        return name;
    }
    public void setName(){
        this.name = name;
    }
    public double getKaina() {
        return kaina;
    }

    public void setKaina(double kaina) {
        this.kaina = kaina;
    }

    public int getTurimasKiekis() {
        return turimasKiekis;
    }

    public void setTurimasKiekis(int turimasKiekis) {
        this.turimasKiekis = turimasKiekis;
    }

    public int getParduotasKiekis() {
        return parduotasKiekis;
    }

    public void setParduotasKiekis(int parduotasKiekis) {
        this.parduotasKiekis = parduotasKiekis;
    }

    @Override
    public String toString() {
        return "Preke [ID: " + id +", Pavadinimas: " + name + ", Kaina: " + kaina + ", Turimas kiekis: " + turimasKiekis + ", Parduotas kiekis: " + parduotasKiekis + "]";
    }
}

