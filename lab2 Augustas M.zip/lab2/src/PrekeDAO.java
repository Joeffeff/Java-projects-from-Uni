import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class PrekeDAO {

    private String jdbcURL = "jdbc:mysql://localhost:3306/parduotuve";
    private String jdbcUsername = "root";
    private String jdbcPassword = "Genmaicha";

    private static final String INSERT_PREKE_SQL = "INSERT INTO prekes (name, kaina, turimasKiekis, parduotasKiekis) VALUES (?, ?, ?, ?)";
    private static final String SELECT_ALL_PREKES = "SELECT * FROM prekes";
    private static final String SELECT_PREKE_BY_ID = "SELECT * FROM prekes WHERE id LIKE ?";

    public PrekeDAO() {}

    protected Connection getConnection() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }
    // Įrašymo metodas
    public void insertPreke(Preke preke) throws SQLException {
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_PREKE_SQL)) {
            preparedStatement.setString(1, preke.getName());
            preparedStatement.setDouble(2, preke.getKaina());
            preparedStatement.setInt(3, preke.getTurimasKiekis());
            preparedStatement.setInt(4, preke.getParduotasKiekis());
            preparedStatement.executeUpdate();
        }
    }

    // Visų prekių atrinkimas
    public List<Preke> selectAllPrekes() {
        List<Preke> prekes = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_PREKES)) {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                String id = rs.getString("id");
                String name = rs.getString("name");
                double kaina = rs.getDouble("kaina");
                int turimasKiekis = rs.getInt("turimasKiekis");
                int parduotasKiekis = rs.getInt("parduotasKiekis");
                prekes.add(new Preke(id,name, kaina, turimasKiekis, parduotasKiekis));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return prekes;
    }

    // Prekių atrinkimas pagal ID fragmentą
    public List<Preke> selectPrekesByIdFragment(String idFragment) {
        List<Preke> prekes = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_PREKE_BY_ID)) {
            preparedStatement.setString(1, "%" + idFragment + "%");
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                String id = rs.getString("id");
                String name = rs.getString("name");
                double kaina = rs.getDouble("kaina");
                int turimasKiekis = rs.getInt("turimasKiekis");
                int parduotasKiekis = rs.getInt("parduotasKiekis");
                prekes.add(new Preke(id,name, kaina, turimasKiekis, parduotasKiekis));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return prekes;
    }
}
