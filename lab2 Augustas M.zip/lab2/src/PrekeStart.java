import javax.swing.*;

public class PrekeStart {
    public static void main(String[] args) {
        SwingUtilities.invokeLater((Runnable) () -> {
            Database setup = new Database();
            setup.createDatabaseAndTable();
            PrekeGUI prekeGUI = new PrekeGUI();  // Initialize the GUI
            prekeGUI.setVisible(true);  // Make the GUI visible
        });
    }
}