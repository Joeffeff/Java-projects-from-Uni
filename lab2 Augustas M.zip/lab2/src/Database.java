import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {

    private String jdbcURL = "jdbc:mysql://localhost:3306/";
    private String jdbcUsername = "root";  // Replace with your MySQL username
    private String jdbcPassword = "Genmaicha";  // Replace with your MySQL password

    public void createDatabaseAndTable() {
        String createDatabaseSQL = "CREATE DATABASE IF NOT EXISTS parduotuve";
        String useDatabaseSQL = "USE parduotuve";
        String createTableSQL = "CREATE TABLE IF NOT EXISTS prekes (" +
                "id INT PRIMARY KEY AUTO_INCREMENT, " +
                "name VARCHAR(255), " +
                "kaina DECIMAL(10, 2), " +
                "turimasKiekis INT, " +
                "parduotasKiekis INT)";

        try (Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             Statement statement = connection.createStatement()) {

            // 1. Create the database
            statement.executeUpdate(createDatabaseSQL);
            System.out.println("Database 'parduotuve' created or already exists.");

            // 2. Switch to the newly created database
            statement.executeUpdate(useDatabaseSQL);

            // 3. Create the table
            statement.executeUpdate(createTableSQL);
            System.out.println("Table 'prekes' created or already exists.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}